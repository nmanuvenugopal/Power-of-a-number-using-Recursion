
def power_calc(base_num, exponent_num):
    assert int(exponent_num) == exponent_num, 'Exponent should be an integer'
    # number raise to 0 is always 1.
    if exponent_num == 0:
        return 1
    # if the base is raised to a negative exponent
    elif exponent_num < 0:
        return 1 / (base_num * power_calc(base_num, exponent_num+1))
    else:
        return base_num * power_calc(base_num, exponent_num-1)


print(f"first case : {power_calc(-1, 2)}")
print(f"second case : {power_calc(3.2, 2)}")
print(f"third case : {power_calc(2, -1)}")
print(f"fourth case : {power_calc(2, 1.2)}")
